const checkEligibility = require('./src/check_eligibility');

const isEligible = checkEligibility(17);

console.log(isEligible)