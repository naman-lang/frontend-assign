import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { IssueService } from 'src/app/services/issue.service';
import { of } from 'rxjs';
import { IssuesListComponent } from './issues-list.component';

describe('IssuesListComponent', () => {
  let component: IssuesListComponent;
  let fixture: ComponentFixture<IssuesListComponent>;
  let issueService: IssueService;
  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ IssuesListComponent ],
      imports: [HttpClientModule],
      providers: [ IssueService]

    })
    .compileComponents();
    issueService = TestBed.get(IssueService);
    spyOn(issueService, 'deleteIssue').and.returnValue(of(''));
    spyOn(issueService, 'getIssues').and.returnValue(of(''));
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IssuesListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // test to check if component exist
  it('should create', () => {

  });

  // test to check ngOnInit method existence
  it('ngOnInit() should exists', () => {

  });

  // test to check deleteIssue is calling IssueService or not
  it('deleteIssue() should call IssueService to delete an Issue', () => {

    });

  // test to check ngOnInit is calling IssueService or not
  it('ngOnInit() should call IssueService to ga Iet all Issues', () => {
    
  });
});
