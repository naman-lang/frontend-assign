export class Todo {
    todoId!: number;
    text!: string;
    isCompleted!: boolean;
}