
// Data model for Issue
export class Post {
    userId!: number;
    id!: number;
    title!: string;
    body!: string;
}

