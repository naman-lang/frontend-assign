const replaceString = (
    str: string,
    toReplace: string,
    replaceWith: string
  ): string => {
    // Check if all inputs are strings.
    if (typeof str !== "string" || typeof toReplace !== "string" || typeof replaceWith !== "string") {
      throw new Error("Invalid Input Types, All Inputs Should Be of Type String !!");
    }
  
    // Use the replace() method to replace all occurrences of the second string with the third string.
    return str.replace(toReplace, replaceWith);
  };