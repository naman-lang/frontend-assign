const checkEligibility = (age) => {
    // Check if age is numeric
    if (isNaN(age)) {
      return "Invalid Age Input, Age Should Only Be Number !!";
    }
    
    // Check if age is 18 or above
    if (age >= 18) {
      return true;
    } else {
      return false;
    }
  };