function checkPhoneNumber(phoneNumber: string): boolean {
  const validPhonePatterns = [
    /^\+1[ ]?099\d{8}$/,
    /^\+1[ ]?099-\d{3}-\d{4}$/,
    /^\+1[ ]?\(099\)-\d{3}-\d{4}$/,
    /^\+1[ ]?\(099\)\d{7}$/,
    /^\+1[ ]?099[ ]?\d{3}[ ]?\d{4}$/,
    /^\+1[ ]?099[ ]?\d{3}-\d{4}$/,
    /^\+1[ ]?\(099\)[ ]?\d{3}-\d{4}$/,
    /^\+1[ ]?099\.\d{3}\.\d{4}$/,
    /^\+1099\d{8}$/,
    /^\+1099-\d{3}-\d{4}$/,
    /^\+1\(099\)-\d{3}-\d{4}$/,
    /^\+1\(099\)\d{7}$/,
    /^\+1099[ ]?\d{3}[ ]?\d{4}$/,
    /^\+1099[ ]?\d{3}-\d{4}$/,
    /^\+1\(099\)[ ]?\d{3}-\d{4}$/,
    /^\+1099\.\d{3}\.\d{4}$/,
  ];
  for (const pattern of validPhonePatterns) {
    if (pattern.test(phoneNumber)) {
      return true;
    }
  }
  return false;
}