import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { StudentComponent } from './student/student.component';
import { TeacherComponent } from './teacher/teacher.component';
 
const routes: Routes = [
  // Add a route for the students component
  {
    path: 'students',
    loadChildren: () => import('./student/student.module').then((m) => m.StudentModule),
  },
  // Add a route for the teachers component
  {
    path: 'teachers',
    loadChildren: () => import('./teacher/teacher.module').then((m) => m.TeacherModule),
  },
  // You can add more routes here if needed
];
 
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}