const getPost = require('./src/apiCall');

// Call getPost() by passing url: https://jsonplaceholder.typicode.com/posts/1 as parameter

// Console log the response received